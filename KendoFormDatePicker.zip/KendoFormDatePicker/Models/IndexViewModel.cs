﻿using System;

namespace KendoFormDatePicker.Models
{
    public class IndexViewModel
    {
        public DateTime DateOfBirth { get; set; } = new DateTime(1950, 04, 15);
    }
}